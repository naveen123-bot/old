<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class reg extends CI_Model {




	public function display_record(){

$query=$this->db->get('country');

return $query->result();

	}


	function fetch_state($id)
 {
  $this->db->where('country_id', $id );
  $this->db->order_by('state_name', 'ASC');
  $query = $this->db->get('state');
  $output = '<option value="">Select State</option>';
  foreach($query->result() as $row)
  {
   $output .= '<option value="'.$row->state_id.'">'.$row->state_name.'</option>';
  }
  return $output;
 }
}