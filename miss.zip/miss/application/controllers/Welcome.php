<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {



public  function _construct(){

	parent::_construct();

	$this->load->model('reg');
}
	
	public function index()



	{


$this->load->model('reg');
 
$result['data']=$this->reg->display_record(); //it will mainly recieves dta from databasethats why we used it.
 
//print_r($result['data']);die;

		$this->load->view('welcome_message',$result);
	}



	function fetch_state()
 {


 	$this->load->model('reg');

 	
 }





}	

